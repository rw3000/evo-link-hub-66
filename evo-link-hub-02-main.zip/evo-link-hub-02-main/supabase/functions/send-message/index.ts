import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    const { instanceId, phoneNumber, message } = await req.json();

    if (!instanceId || !phoneNumber || !message) {
      return new Response(JSON.stringify({ error: 'Missing required fields' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Get instance details from Evolution API directly
    const evolutionApiUrl = Deno.env.get('EVOLUTION_API_URL')!;
    const evolutionApiKey = Deno.env.get('EVOLUTION_API_KEY')!;
    
    // Get instance info first
    const instanceResponse = await fetch(`${evolutionApiUrl}/instance/fetchInstances`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'apikey': evolutionApiKey,
      },
    });

    if (!instanceResponse.ok) {
      return new Response(JSON.stringify({ error: 'Failed to get instance info' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const instances = await instanceResponse.json();
    const instance = instances.find((inst: any) => inst.id === instanceId);
    
    if (!instance) {
      return new Response(JSON.stringify({ error: 'Instance not found in Evolution API' }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Send message via Evolution API using instance name
    const evolutionResponse = await fetch(`${evolutionApiUrl}/message/sendText/${instance.name}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': evolutionApiKey,
      },
      body: JSON.stringify({
        number: phoneNumber,
        text: message,
      }),
    });

    if (!evolutionResponse.ok) {
      const errorData = await evolutionResponse.text();
      console.error('Evolution API error:', errorData);
      return new Response(JSON.stringify({ error: 'Failed to send message via Evolution API' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const evolutionData = await evolutionResponse.json();
    console.log('Message sent via Evolution API:', evolutionData);

    // Store message in our database (optional for tracking)
    try {
      const supabase = createClient(supabaseUrl, supabaseServiceKey);
      
      // Save message to database for tracking
      const { error: messageError } = await supabase
        .from('evolution_messages')
        .insert([{
          instance_id: instanceId,
          empresa_id: 'temp-empresa-id', // You might need to get this from somewhere
          message_id: evolutionData.message?.id || 'unknown',
          chat_id: phoneNumber,
          from_number: instance.ownerJid || 'system',
          to_number: phoneNumber,
          message_type: 'text',
          content: message,
          direction: 'outgoing',
          status: 'sent',
          timestamp: new Date().toISOString(),
        }]);

      if (messageError) {
        console.error('Error saving message to database:', messageError);
      }
    } catch (dbError) {
      console.error('Database operation failed:', dbError);
      // Don't fail the request if database save fails
    }

    return new Response(JSON.stringify({ success: true, data: evolutionData }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Send message error:', error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});