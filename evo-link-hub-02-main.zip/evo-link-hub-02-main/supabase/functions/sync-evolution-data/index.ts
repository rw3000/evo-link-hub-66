import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const evolutionApiUrl = Deno.env.get('EVOLUTION_API_URL')!;
const evolutionApiKey = Deno.env.get('EVOLUTION_API_KEY')!;

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    const { instanceId } = await req.json();

    if (!instanceId) {
      return new Response(JSON.stringify({ error: 'Instance ID is required' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log('Syncing data for instance:', instanceId);

    // Get instance info first
    const instanceResponse = await fetch(`${evolutionApiUrl}/instance/fetchInstances`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'apikey': evolutionApiKey,
      },
    });

    if (!instanceResponse.ok) {
      throw new Error('Failed to get instance info');
    }

    const instances = await instanceResponse.json();
    const instance = instances.find((inst: any) => inst.id === instanceId);
    
    if (!instance) {
      return new Response(JSON.stringify({ error: 'Instance not found' }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Sync contacts
    const contactsResponse = await fetch(`${evolutionApiUrl}/chat/findContacts/${instance.name}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'apikey': evolutionApiKey,
      },
    });

    if (contactsResponse.ok) {
      const contacts = await contactsResponse.json();
      console.log(`Found ${contacts.length} contacts for instance ${instance.name}`);

      for (const contact of contacts) {
        // Upsert contact
        const { error: contactError } = await supabase
          .from('evolution_crm_contatos')
          .upsert({
            instance_id: instanceId,
            empresa_id: 'temp-empresa-id', // You might need to get this from somewhere
            numero: contact.id.replace('@s.whatsapp.net', ''),
            nome: contact.pushName || contact.name || null,
            avatar_url: contact.profilePicUrl || null,
            ultima_interacao: new Date().toISOString(),
          }, {
            onConflict: 'instance_id,numero'
          });

        if (contactError) {
          console.error('Error upserting contact:', contactError);
        }
      }
    }

    // Sync messages
    const messagesResponse = await fetch(`${evolutionApiUrl}/chat/findMessages/${instance.name}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': evolutionApiKey,
      },
      body: JSON.stringify({
        where: {
          fromMe: false // Get only received messages initially
        },
        limit: 100
      }),
    });

    if (messagesResponse.ok) {
      const messages = await messagesResponse.json();
      console.log(`Found ${messages.length} messages for instance ${instance.name}`);

      for (const message of messages) {
        // Find or create contact
        const contactNumber = message.key.remoteJid.replace('@s.whatsapp.net', '');
        
        let { data: contact } = await supabase
          .from('evolution_crm_contatos')
          .select('id')
          .eq('instance_id', instanceId)
          .eq('numero', contactNumber)
          .single();

        if (!contact) {
          const { data: newContact } = await supabase
            .from('evolution_crm_contatos')
            .insert({
              instance_id: instanceId,
              empresa_id: 'temp-empresa-id',
              numero: contactNumber,
              ultima_interacao: new Date(message.messageTimestamp * 1000).toISOString(),
            })
            .select('id')
            .single();
          
          contact = newContact;
        }

        if (contact) {
          // Find or create conversation
          let { data: conversation } = await supabase
            .from('evolution_crm_conversas')
            .select('id')
            .eq('instance_id', instanceId)
            .eq('contato_id', contact.id)
            .single();

          if (!conversation) {
            const { data: newConversation } = await supabase
              .from('evolution_crm_conversas')
              .insert({
                instance_id: instanceId,
                empresa_id: 'temp-empresa-id',
                contato_id: contact.id,
                status: 'open',
              })
              .select('id')
              .single();
            
            conversation = newConversation;
          }

          if (conversation) {
            // Save message
            const { error: messageError } = await supabase
              .from('evolution_crm_mensagens')
              .upsert({
                conversa_id: conversation.id,
                empresa_id: 'temp-empresa-id',
                numero_remetente: contactNumber,
                numero_destinatario: instance.ownerJid || 'system',
                conteudo: message.message?.conversation || message.message?.extendedTextMessage?.text || 'Mensagem sem texto',
                tipo: message.message?.conversation ? 'text' : 'other',
                direcao: message.key.fromMe ? 'outgoing' : 'incoming',
                timestamp_evolution: new Date(message.messageTimestamp * 1000).toISOString(),
                status: 'received',
              }, {
                onConflict: 'conversa_id,timestamp_evolution,numero_remetente'
              });

            if (messageError) {
              console.error('Error saving message:', messageError);
            }
          }
        }
      }
    }

    return new Response(JSON.stringify({ 
      success: true, 
      message: 'Data synchronized successfully',
      instanceId: instanceId 
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Sync error:', error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});